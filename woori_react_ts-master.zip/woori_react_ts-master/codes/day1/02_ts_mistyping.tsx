import "./App.css";

function testFunc() {
  console.log("테스트");
}

export default function App() {
  return (
    <>
      <button onClick={() => tessFunc()}>클릭</button>
    </>
  );
}