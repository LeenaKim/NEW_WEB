import "./App.css";
import { useState } from "react";

export default function App() {
  const [orderCount, setOrderCount] = useState(0);
  return (
    <>
      {orderCount && <div>물건이 있습니다.</div>}
    </>
  );
}