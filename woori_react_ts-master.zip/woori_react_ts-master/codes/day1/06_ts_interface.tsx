import "./App.css";

interface User {
  id: number;
  firstName: string;
  lastName: string;
  role: string;
}

function testInterface(user: User) {
  console.log(user);
}

export default function App() {
  return (
    <>
      <button onClick={() => testInterface({
        id: 1,
        firstName: "jony",
        lastName: "lee",
        // role: "coding teacher"
      })}>클릭</button>
    </>
  );
}