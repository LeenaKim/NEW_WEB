import "./App.css";
import { useState } from "react";

export default function App() {
  const [selectedColor, setSelectedColor] = useState("");
  return (
    <>
      <h1
        style={{ color: selectedColor }}
        onClick={(e) => {
          console.dir(e.target);
          console.log(e.target.style);
        }}
      >
        color
      </h1>
      <button onClick={() => setSelectedColor("red")}>빨강</button>
      <button onClick={() => setSelectedColor("blue")}>파랑</button>
    </>
  );
}
