import "./App.css";
import { useState } from "react";

export default function App() {
  const [message, setMessage] = useState("");

  function print() {
    setMessage("hi");
    console.log("work");
  }

  print();

  return (
    <>
      <h1>Infinite loof</h1>
    </>
  );
}
