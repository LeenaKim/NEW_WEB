import "./App.css";
import { useState } from "react";

export default function App() {
  const [url, setUrl] = useState("");
  return (
    <>
      <a href={url}>어디로 갈까?</a>
      <div>
        <button
          onClick={() => {
            setUrl("https://naver.com");
          }}
        >
          네이버
        </button>
        <button
          onClick={() => {
            setUrl("https://google.com");
          }}
        >
          구글
        </button>
      </div>
    </>
  );
}