import "./App.css";
import { useState } from "react";

export default function App() {
  const [isActive, setIsActive] = useState(false);
  return (
    <>
      <button
        onClick={() => setIsActive(!isActive)}
      >
        토글 버튼
      </button>
      {isActive && <div>짠</div>}
    </>
  );
}