import "./App.css";
import { useState } from "react";
export default function App() {
  const [message, setMessage] = useState("");
  return (
    <>
      <div>message: {message}</div>
      <input
        value={message}
        onChange={(e) => {
          console.log(e.target);
          setMessage(e.target.value);
        }}
      />
    </>
  );
}
