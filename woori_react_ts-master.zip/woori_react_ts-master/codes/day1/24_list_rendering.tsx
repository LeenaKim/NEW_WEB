import "./App.css";

export default function App() {
  const menus = [
    {
      id: 1,
      name: "짜장면",
      isRecommend: true,
    },
    {
      id: 2,
      name: "짬뽕",
      isRecommend: false,
    },
    {
      id: 3,
      name: "탕수육",
      isRecommend: true,
    },
  ];
  return (
    <>
      <ul>
        {menus.map((menu) => (
          <li key={menu.id}>{menu.name}</li>
        ))}
      </ul>
    </>
  );
}