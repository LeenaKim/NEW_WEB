import "./App.css";
import { useState } from "react";

export default function App() {
  const [ message, setMessage ] = useState("Hello React");
  return (
    <>
      <p className="test-class">message: { message }</p>
      <img src="./test.jpg" alt="test image" />
      <input type="text" />
    </>
  );
}
