import { useState } from "react";
export default function App() {
  const [userInput, setUserInput] = useState("");
  function work() {
    console.log("실행");
  }
  return (
    <>
      <input
        type="text"
        value={userInput}
        onChange={(e) => {
          setUserInput(e.target.value);
        }}
      />
      <button onClick={() => userInput && work()}>실행</button>
    </>
  );
}
