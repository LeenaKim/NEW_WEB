import AppIcons from "./AppIcons";

export default function AppHeader() {
  return (
    <>
      <h2>AppHeader</h2>
      <AppIcons />
    </>
  );
}
