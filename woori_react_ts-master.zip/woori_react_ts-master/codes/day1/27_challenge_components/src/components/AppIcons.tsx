export default function AppIcons() {
  return (
    <>
      <h3>AppIcons</h3>
    </>
  );
}
