import "./App.css";
import { useState } from "react";
export default function App() {
  const [text, setText] = useState("???");
  return (
    <>
      <div>{text}</div>
      <button
        onClick={(e) => {
          console.log(e);
          setText("짜잔");
        }}
      >
        클릭
      </button>
    </>
  );
}
