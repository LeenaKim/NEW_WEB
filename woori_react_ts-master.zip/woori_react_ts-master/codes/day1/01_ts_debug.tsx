import { useState } from "react";
import "./App.css";

export default function App() {
  const [message, setMessage] = useState("Hello React");
  return (
    <>
      <p>message: {message}</p>
    </>
  );
}
