import "./App.css";
import { useState } from "react";
export default function App() {
  const [text1, setText1] = useState("???");
  let text2 = "???";
  return (
    <>
      <div>{text1}</div>
      <div>{text2}</div>
      <button onClick={() => setText1("짜잔")}>text1 변경</button>
      <button onClick={() => text2 = "짜잔"}>text2 변경</button>
    </>
  );
}
