import "./App.css";
import { useState } from "react";

export default function App() {
  const [isActive, setIsActive] = useState(false);
  let content;
  if (isActive) {
    content = <div>짠</div>;
  } else {
    content = <div>안보임</div>;
  }
  return (
    <>
      <button
        onClick={() => setIsActive(!isActive)}
      >
        토글 버튼
      </button>
      {content}
    </>
  );
}