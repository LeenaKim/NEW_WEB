import "./App.css";

// function testParamType(name) {
//   console.log(name);
// }

function testParamType(name: string) {
  console.log(name);
}

export default function App() {
  return (
    <>
      <button onClick={() => testParamType(1)}>클릭</button>
    </>
  );
}