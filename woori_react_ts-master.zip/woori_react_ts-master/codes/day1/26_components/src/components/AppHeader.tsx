export default function AppHeader() {
  return (
    <>
      <h2>AppHeader</h2>
    </>
  );
}
