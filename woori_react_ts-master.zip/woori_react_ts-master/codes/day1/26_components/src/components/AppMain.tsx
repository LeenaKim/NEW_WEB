export default function AppMain() {
  return (
    <>
      <h2>AppMain</h2>
    </>
  );
}
