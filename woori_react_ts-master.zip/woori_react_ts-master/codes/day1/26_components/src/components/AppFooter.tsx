export default function AppFooter() {
  return (
    <>
      <h2>AppFooter</h2>
    </>
  );
}
