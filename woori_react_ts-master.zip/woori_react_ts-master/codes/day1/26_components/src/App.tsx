import "./App.css";
import AppHeader from "./components/AppHeader";
import AppMain from "./components/AppMain";
import AppFooter from "./components/AppFooter";

export default function App() {
  return (
    <>
      <h1>hello</h1>
      <AppHeader />
      <AppMain />
      <AppFooter />
    </>
  );
}