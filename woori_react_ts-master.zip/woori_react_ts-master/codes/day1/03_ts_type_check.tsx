import "./App.css";

const user = {
  firstName: "Angela",
  lastName: "Davis",
  role: "Professor",
}

function testTypeCheck() {
  console.log(user.name);
}

export default function App() {
  return (
    <>
      <button onClick={() => testTypeCheck()}>클릭</button>
    </>
  );
}