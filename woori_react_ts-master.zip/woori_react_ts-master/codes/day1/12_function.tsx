import "./App.css";
import { useState } from "react";

export default function App() {
	const [text, setText] = useState("???");

	function printHello() {
		console.log("hello");
	}

	return (
		<>
			<div>{text}</div>
			<button
				onClick={() => {
					printHello();
					setText("짜잔");
				}}
			>
				클릭
			</button>
		</>
	);
}
