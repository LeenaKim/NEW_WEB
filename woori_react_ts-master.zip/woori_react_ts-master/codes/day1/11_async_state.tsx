import "./App.css";
import { useState } from "react";
export default function App() {
  const [text1, setText1] = useState("???");
  const [text2, setText2] = useState("???");
  return (
    <>
      <div>{text1}</div>
      <div>{text2}</div>
      <button
        onClick={() => {
          setText1("짜잔");
          setText2(text1);
        }}
      >
        둘 다 변경
      </button>
    </>
  );
}
