import "./App.css";
import { useState } from "react";

export default function App() {
  const URL = "https://jsonplaceholder.typicode.com/todos";
  const [data, setData] = useState([]);

  return (
    <>
      <h1>Data Fetch</h1>
      <button
        onClick={async () => {
          try {
            const response = await fetch(URL, { method: "GET" });
            console.log(response);
            const jsonData = await response.json();
            console.log(jsonData);
            setData(jsonData);
          } catch (error) {
            console.error(error);
          }
        }}
      >
        서버에서 가져오기
      </button>
      <ul>
        {data.map((item) => (
          <li key={item.id}>{item.title}</li>
        ))}
      </ul>
    </>
  );
}