import ChairMan from './components/ChairMan'
import './App.css'

export default function App() {

  return (
    <>
      <ChairMan />
    </>
  )
}

