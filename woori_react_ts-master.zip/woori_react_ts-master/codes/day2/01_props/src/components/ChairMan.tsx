import { useState } from 'react';
import BusinessMan from './BusinessMan';

export default function ChairMan() {
  const [name, setName] = useState<string>("woori company")
  const [age, setAge] = useState<number>(125)

  function handleName(newName: string) {
    setName(newName)
  }

  return (
    <>
      <h1>회장 - 가장 높은 직급</h1>
      <p>{name}</p>
      <p>{age}</p>
      <button onClick={() => setAge(age - 1)}>나이 감소</button>
      <BusinessMan 
        name={name} 
        age={age}
        handleName={handleName}
      />
    </>
  );
}



