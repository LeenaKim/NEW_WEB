interface FreshManProps {
    name: string,
    age: number,
    // 부모로 부터 이벤트를 전달 받는다.
    handleA4: () => void
}

export default function FreshMan(
        { name, age, handleA4 }: FreshManProps) {
  return (
    <>
      <h1>신입사원 - 가장 아래 직급</h1>
      <p>{name}</p>
      <p>{age}</p>
      {/* 버튼 클릭 시 전달받은 이벤트 수행 */}
      <button onClick={handleA4}>A4 출력 해주세요!</button>
    </>
  );
}

