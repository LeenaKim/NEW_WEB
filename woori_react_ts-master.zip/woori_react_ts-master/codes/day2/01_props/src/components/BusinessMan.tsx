import { useState } from 'react';
import FreshMan from './FreshMan';

interface BusinessManProps {
    name: string,
    age: number,
    handleName: (newName: string) => void
}
    
export default function BusinessMan(
        { name, age, handleName }: BusinessManProps) {
  const [A4, setA4] = useState<string>('blank')
  function handleA4() {
    setA4('A4 출력이 완료되었습니다. 신입사원님')
  }

  return (
    <>
      <h1>대리 - 중간 직급</h1>
      <p>{name}</p>
      <p>{age}</p>
      <p>{A4}</p>
      <button onClick={() => handleName("우리회사")}>회사 이름 바꿔주세요!</button>
      <FreshMan name={name} age={age} handleA4={handleA4}/>
    </>
  );
}

