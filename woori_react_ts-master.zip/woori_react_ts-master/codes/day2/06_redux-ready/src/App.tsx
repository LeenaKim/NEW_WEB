import ChairMan from "./components/ChairMan"

export default function App() {
  return (
    <>
      <ChairMan />
    </>
  );
}
