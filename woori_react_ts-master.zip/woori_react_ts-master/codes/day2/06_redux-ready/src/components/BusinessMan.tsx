import FreshMan from "./FreshMan";

function handleNameClick() {
  console.log("회사 이름 바꿔주세요!");
}

export default function BusinessMan() {
  return (
    <>
      <h2>대리 - 중간 직급</h2>
      <p>name</p>
      <p>age</p>
      <button onClick={handleNameClick}>회사 이름 바꿔주세요!</button>
      <FreshMan />
    </>
  );
}
