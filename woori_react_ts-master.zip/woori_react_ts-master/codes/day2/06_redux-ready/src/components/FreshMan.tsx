export default function FreshMan() {
  return (
    <>
      <h3>신입사원 - 가장 아래 직급</h3>
      <p>name</p>
      <p>age</p>
    </>
  );
}
