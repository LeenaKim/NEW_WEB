import BusinessMan from "./BusinessMan";

function handleAgeClick() {
  console.log("나이 감소");
}

export default function ChairMan() {
  return (
    <>
      <h1>회장 - 가장 높은 직급</h1>
      <p>name</p>
      <p>age</p>
      <button onClick={handleAgeClick}>나이 감소</button>
      <BusinessMan />
    </>
  );
}
