"use client";

import { useState, useEffect } from "react";
import { fetchArticle } from "@/app/lib/data";
import { Article } from "@/app/lib/definitions";
import Loading from "@/app/ui/loading";
import { parseDate } from "@/app/lib/utils";
import { useParams } from "next/navigation";

export default function Page() {
  const params = useParams();

  const [article, setArticle] = useState<Article | null>(null);

  async function initData() {
    const foundArticle = await fetchArticle(Number(params.id));
    setArticle(foundArticle);
  }

  useEffect(() => {
    initData();
  }, []);

  return (
    <>
      {article ? (
        <>
          <div className="w-full">
            <h2 className="text-3xl font-bold mb-6">{article.title}</h2>
            <p>작성자: {article.username}</p>
            <p>{article.content}</p>
            <p>작성시간: {parseDate(article.createdAt)}</p>
            <p>수정시간: {parseDate(article.updatedAt)}</p>
          </div>
        </>
      ) : (
        <Loading />
      )}
    </>
  );
}
