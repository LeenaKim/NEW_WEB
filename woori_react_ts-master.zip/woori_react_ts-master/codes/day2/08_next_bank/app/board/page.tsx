"use client";

import { useState, useEffect } from "react";
import { fetchArticles } from "@/app/lib/data";
import { Article } from "@/app/lib/definitions";
import Loading from "@/app/ui/loading";
import { parseDate } from "@/app/lib/utils";
import Link from "next/link";

export default function Page() {
  const [articles, setArticles] = useState<Article[]>([]);

  async function initData() {
    const foundArticles = await fetchArticles();
    setArticles(foundArticles);
  }

  useEffect(() => {
    initData();
  }, []);

  return (
    <>
      {articles.length > 0 ? (
        <div className="w-full max-w-4xl overflow-x-auto">
          <table className="table-auto w-full border-collapse">
            <thead>
              <tr>
                <th className="border-b border-gray-500 p-4">제목</th>
                <th className="border-b border-gray-500 p-4">작성자</th>
                <th className="border-b border-gray-500 p-4">작성시간</th>
              </tr>
            </thead>
            <tbody>
              {articles.map((article) => (
                <tr key={article.id} className="bg-gray-800">
                  <td className="border-b border-gray-600 p-4">
                    <Link href={`board/${article.id}`}>{article.title}</Link>
                  </td>
                  <td className="border-b border-gray-600 p-4">
                    {article.username}
                  </td>
                  <td className="border-b border-gray-600 p-4">
                    {parseDate(article.createdAt)}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <Loading />
      )}
    </>
  );
}
