import axios from "axios";
import { Product, Article } from "@/app/lib/definitions";

// 실제
// const serverUrl = process.env.NEXT_PUBLIC_SERVER_URL;

// 테스트용
import sampleProducts from "@/app/lib/sample/products.json";
import sampleArticles from "@/app/lib/sample/articles.json";

export async function fetchProducts(): Promise<Product[]> {
  try {
    // 실제
    // const response = await axios.get(sampleProducts);
    // return response.data;

    // 테스트
    return sampleProducts.data as Product[];
  } catch (error) {
    console.error(`error: ${error}`);
    return [];
  }
}

export async function fetchArticles(): Promise<Article[]> {
  try {
    return sampleArticles.data as Article[];
  } catch (error) {
    console.error(`error: ${error}`);
    return [];
  }
}

export async function fetchArticle(id: number): Promise<Article | null> {
  try {
    return sampleArticles.data.filter((article) => article.id === id)[0];
  } catch (error) {
    console.error(`error: ${error}`);
    return null;
  }
}
