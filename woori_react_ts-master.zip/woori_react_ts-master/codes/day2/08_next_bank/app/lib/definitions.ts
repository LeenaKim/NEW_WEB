export type Article = {
  id: number;
  username: string;
  title: string;
  content: string;
  createdAt: string;
  updatedAt: string;
};

export type Product = {
  id: number;
  dclsMonth: string;
  korCoNm: string;
  finPrdtNm: string;
  joinDeny: string;
  spclCnd: string;
};
