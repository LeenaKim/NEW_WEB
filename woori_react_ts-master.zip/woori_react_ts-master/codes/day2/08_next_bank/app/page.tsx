export default function Home() {
  return (
    <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-gray-700 via-gray-900 to-black text-white">
      <h1 className="text-4xl font-bold mb-4">Next.js Bank</h1>
      <h2 className="text-2xl text-gray-300 italic">
        당신의 금융 생활을 혁신적으로
      </h2>
    </main>
  );
}
