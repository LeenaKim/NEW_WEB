"use client";

import { useState, useEffect } from "react";
import { fetchProducts } from "@/app/lib/data";
import { Product } from "@/app/lib/definitions";
import Loading from "@/app/ui/loading";

export default function Page() {
  const [products, setProducts] = useState<Product[]>([]);

  async function initData() {
    const foundProducts = await fetchProducts();
    setProducts(foundProducts);
  }

  useEffect(() => {
    initData();
  }, []);

  return (
    <>
      {products.length > 0 ? (
        <ul className="w-full max-w-4xl space-y-6">
          {products.map((product) => (
            <li
              key={product.id}
              className="bg-gray-800 p-6 rounded-lg shadow-md transform transition-transform duration-200 hover:scale-105 hover:cursor-pointer"
            >
              <p className="text-xl font-semibold">{product.finPrdtNm}</p>
              <p>공시연월: {product.dclsMonth}</p>
              <p>금융기관: {product.korCoNm}</p>
              <p>가입제한: {product.joinDeny}</p>
              <p>우대사항: {product.spclCnd}</p>
            </li>
          ))}
        </ul>
      ) : (
        <Loading />
      )}
    </>
  );
}
