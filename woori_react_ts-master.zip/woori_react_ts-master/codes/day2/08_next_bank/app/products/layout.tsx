export default function Layout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <>
      <main className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-r from-gray-700 via-gray-900 to-black text-white p-8">
        <h2 className="text-3xl font-bold mb-6">상품 리스트</h2>
        <hr className="border-gray-500 w-full mb-6" />
        {children}
      </main>
    </>
  );
}
