import type { Metadata } from "next";
import { Noto_Sans_KR } from "next/font/google";
import "./globals.css";
import SideNav from "@/app/ui/side-nav";

const notoSansKr = Noto_Sans_KR({ subsets: ["latin"], weight: ["400", "700"] });

export const metadata: Metadata = {
  title: "Next.js Bank",
  description: "Next.js 를 사용하는 은행 웹앱",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ko">
      <body className={notoSansKr.className}>
        <div className="flex min-h-screen">
          <SideNav />
          <main className="flex-1">{children}</main>
        </div>
      </body>
    </html>
  );
}
