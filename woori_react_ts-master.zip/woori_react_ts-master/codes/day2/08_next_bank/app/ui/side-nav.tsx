"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import clsx from "clsx";

const links = [
  { name: "Home", href: "/" },
  { name: "Board", href: "/board" },
  { name: "Products", href: "/products" },
];

export default function SideNav() {
  const pathname = usePathname();
  return (
    <>
      <nav className="bg-gray-800 text-white w-64 min-h-screen px-4 py-8">
        <ul className="space-y-2">
          {links.map((link) => (
            <li key={link.name}>
              <Link
                href={link.href}
                className={clsx(
                  "flex items-center p-3 rounded-lg transition-colors duration-200",
                  {
                    "bg-sky-500 text-white": pathname === link.href,
                    "text-gray-400 hover:bg-sky-400 hover:text-white": pathname !== link.href,
                  }
                )}
              >
                <span>{link.name}</span>
              </Link>
            </li>
          ))}
        </ul>
      </nav>
    </>
  );
}
