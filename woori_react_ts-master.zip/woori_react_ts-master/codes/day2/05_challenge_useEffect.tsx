import "./App.css";
import { useState, useEffect } from "react";

// User 타입 정의
interface User {
  id: number;
  name: string;
  email: string;
}

export default function App() {
  const URL = "https://jsonplaceholder.typicode.com/users";
  const [users, setUsers] = useState<User[]>([]);

  async function dataFetch() {
    console.log('work')
    try {
      const response = await fetch(URL, { method: "GET" });
      const jsonData = await response.json();
      setUsers(jsonData);
    } catch (error) {
      console.error(error);
    }
  }

  // useEffect를 사용해 컴포넌트가 처음 렌더링될 때만 dataFetch 호출
  useEffect(() => {
    dataFetch();
  }, []); // 빈 배열을 넣으면 컴포넌트가 처음 마운트될 때만 실행됨

  return (
    <>
      <h1>Data Fetch</h1>
      {users.length ? (
        <ul>
          {users.map((user) => (
            <li key={user.id}>
              <p>{user.name}</p>
              <p>{user.email}</p>
            </li>
          ))}
        </ul>
      ) : (
        <p>Loading...</p>
      )}
    </>
  );
}
