import { TypedUseSelectorHook, useDispatch, useSelector } from "react-redux";
import { RootState, AppDispatch } from './store'

// 컴포넌트 코드에서 직접 store 코드를 가져가는 게 아닌
// 아래 hook 을 통해서 가져가도록 구현

export const useAppDispatch = () => useDispatch<AppDispatch>();


// useSelector: 실제 react-redux 의 function 으로, redux 스토어의 상태를 선택하는 함수
// useAppSelector: 우리가 사용할 selector 의 alias(별칭)
// TypedUseSelectorHook<RootState> : state 들에 대한 타입 정의
export const useAppSelector: TypedUseSelectorHook<RootState> = useSelector;