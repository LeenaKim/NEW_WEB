// redux 에서 store 를 생성하기 위한 기본 함수
// 1. redux dev tools extensions 이 자동으로 켜짐
// 2. Thunk 미들웨어를 자동으로 추가
// -> 일반적인 실수 들을 같이 잡아줌

import { configureStore } from "@reduxjs/toolkit";
import companyReducer from '../features/company/company-slice'

// store 생성
export const store = configureStore({
    reducer: {
        company: companyReducer
    }
});

// TypeScript 관련 작업

// 컴포넌트에서 action 을 디스패치 할 때
// 각 액션의 타입들을 정의해야 하는데, 아래와 같이 추가할 수 있다.
export type AppDispatch = typeof store.dispatch;


// TS 가 가진 ReturnType 을 활용
// RootState 위에 마우스 올려보면 State 의 type 을 자동으로 return 하도록 할 수 있음
// 이러면 직접 하나하나 선언해줄 필요가 없다! 
export type RootState = ReturnType<typeof store.getState>;