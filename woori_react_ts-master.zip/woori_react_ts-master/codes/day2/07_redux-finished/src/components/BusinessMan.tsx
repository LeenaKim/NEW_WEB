import { useState } from 'react';
import { useAppDispatch, useAppSelector } from '../app/hooks';
import { handleName } from '../features/company/company-slice';
import FreshMan from './FreshMan';

export default function BusinessMan() {
  const name = useAppSelector((state) => state.company.name);
  const age = useAppSelector((state) => state.company.age);

  const dispatch = useAppDispatch();

  function handleNameClick() {
    dispatch(handleName("우리회사"));
  }


  // 전체에서 다 쓰는게 아니라, 두 컴포넌트에서만 활용되는 코드는 그냥 emit props 로 활용
  const [A4, setA4] = useState<string>('blank')

  function handleA4() {
    setA4('A4 출력이 완료되었습니다. 신입사원님')
  }
  return (
    <>
      <h1>대리 - 중간 직급</h1>
      <p>{name}</p>
      <p>{age}</p>
      <p>{A4}</p>
      <button onClick={handleNameClick}>회사 이름 바꿔주세요!</button>
      <FreshMan handleA4={handleA4}/>
    </>
  );
}

