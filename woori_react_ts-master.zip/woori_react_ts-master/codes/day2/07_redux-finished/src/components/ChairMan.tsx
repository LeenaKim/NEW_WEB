import { useAppDispatch, useAppSelector } from '../app/hooks';
import { handleAge } from '../features/company/company-slice';
import BusinessMan from './BusinessMan';

export default function ChairMan() {
  const name = useAppSelector((state) => state.company.name);
  const age = useAppSelector((state) => state.company.age);

  const dispatch = useAppDispatch();

  function handleAgeClick() {
    dispatch(handleAge());
  }

  return (
    <>
      <h1>회장 - 가장 높은 직급</h1>
      <p>{name}</p>
      <p>{age}</p>
      <button onClick={handleAgeClick}>나이 감소</button>
      <BusinessMan />
    </>
  );
}


