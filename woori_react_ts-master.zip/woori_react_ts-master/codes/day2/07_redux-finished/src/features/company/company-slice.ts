// createSlice: redux 로직을 작성할 주요 API 함수
//   - redux 에서 관련 로직을 최대한 단일 파일에 구겨 넣는 것을 권장
//   - 하나의 조각에 구겨 넣는다 라는 의미로 slice 라고 부름
// PayloadAction: reducer 에서 파라미터 전달 받을 때 사용하는 Typescript 용 타입
import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface CompanyState {
    name: string,
    age: number,
}

const initialState: CompanyState = {
    name: 'woori',
    age: 125
}

const companySlice = createSlice({
    name: 'company',
    initialState,
    reducers: {
        handleName(state, action: PayloadAction<string>) {
            state.name = action.payload;
        },
        handleAge(state) {
            state.age--;
        },
        handleAgeToOne(state) {
            state.age = 1;
        }
    }
})

export const { handleName, handleAge, handleAgeToOne } = companySlice.actions;

export default companySlice.reducer;